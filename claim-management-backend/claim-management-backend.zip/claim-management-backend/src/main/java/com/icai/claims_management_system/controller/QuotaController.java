package com.icai.claims_management_system.controller;

public class QuotaController {

}
