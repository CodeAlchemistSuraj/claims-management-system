# claims-management-system
Claims Management System: Spring Boot application providing secure REST APIs, JPA-based persistence with PostgreSQL, Flyway migrations, and Spring Security. Designed to streamline insurance claim intake, tracking, and processing with modular services, test coverage, and production-ready deployment configuration. CI/CD
