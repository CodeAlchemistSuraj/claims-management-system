package com.icai.claims_management_system;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClaimsManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClaimsManagementSystemApplication.class, args);
	}

}
