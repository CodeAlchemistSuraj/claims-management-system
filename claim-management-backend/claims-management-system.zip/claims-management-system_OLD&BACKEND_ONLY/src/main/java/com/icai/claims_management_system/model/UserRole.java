package com.icai.claims_management_system.model;

public enum UserRole {
    ROLE_USER,
    ROLE_ADMIN
}
